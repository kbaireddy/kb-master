# lp-store-server
A basic RESTful server for training purposes

Here is another change to trigger a new build

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
