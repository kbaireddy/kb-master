
let plates = require('./data/plates.json');
let states = require('./data/US_states.json');
let cart = [];

module.exports = {plates: plates, cart: cart, states: states};
